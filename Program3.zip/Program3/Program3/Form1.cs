﻿//Grading ID: S5008
//Lab Number: Program 03
//Due Date: November 11, 11:59 P.M.
//Course Section: CIS 199-50-4218
//Program Description: Program that allows the user to input info for Item numbers, numbers of servings, and the city and make calculations for costs depending on user inputs.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Declared all the arrays that were needed for use in the calclulations.
        //Declared all the constant values that were needed for use in the calculations.
        //Created a STRING ARRAY to represent the cities.
        string[] Cities = { "Louisville", "Lexington", "Indianapolis", "Nashville" };
        //Created a DOUBLE ARRAY to represent the associated shipment fees according to the cities.
        double[] ShipmentFee = { 0.06, 0.0717, 0.07, 0.0874 };                               
        //Created INT ARRAY to represent the Item numbers.
        int[] ItemNumberArray = { 10001, 10002, 10003, 10004, 10005, 10006, 10007 };     
        //Created a CONST INT for the Maximum Item number for validating the item number text box.
        const int MinItemNumber = 10001;                                                                
        //Created a CONST INT for the Maximum Item number for validating the item number text box.
        const int MaxItemNumber = 10007;
        //Created DOUBLE ARRAY to represent the cost per seving for the entree numbers (items).
        double[] CostPerServing = {7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 };         
        //Created INT ARRAY to represent the Servings range values.
        int[] ServingsRangeValues = { 5, 10, 15 };
        //Created INT ARRAY to represent the service fees associated with the servings range declared immediately above.
        double[] ServiceFees = { 0.15, 0.10, 0.05 };                                               
        //Created a CONST INT variable for the maximum quantity before there is no service charge.
        const int MaxFreeServiceForServings = 21;

        //Event Handler to initially validate the inputs for the City, Item Number, and the Quantity of Servings on the Form.
        private void btnCalculate_Click(object sender, EventArgs e)                                     
        {
            //Variable for the input of the Entree or the Item number text box on the Form.
            int ItemNumber;
            //Variable for the input of the Quantity or Servings text box on the Form.
            int QuantityServings;                                                                       
            //Variable for the Initial cost of the the Entree and Item number selected.
            double InitialCost;
            //Variable that represents the service fee that changes depending on the selections made 
            double VariableServiceFee;
            
            
            //Initial Validation of the data selected or entered into the text boxes and cbox on the form.
            //Shows a Message box with errors and requests to input correct data into form.
            if (cbxCity.SelectedIndex ==-1)
            {
                MessageBox.Show("Error! Please Select a City!");
            }
            else if (int.TryParse(txtEntreeOrItemNumber.Text, out ItemNumber) == false || ItemNumber < MinItemNumber || ItemNumber > MaxItemNumber)
            {
                MessageBox.Show("Error! Please Enter a Valid Item Number!");
            }
            else if (int.TryParse(txtQuantityServings.Text, out QuantityServings) == false || QuantityServings < 0)
            {
                MessageBox.Show("Error! Please Enter a Valid Quantity of Servings!");
            }

            //If everything above is correct with the "If" and "Else If" statements, then move to the first "else" for everything being validated. 
            //All calculation contained within the first "else" statement after initial validation of data.
            else
            {
                InitialCost = CostPerServing [ItemNumber % MinItemNumber]* QuantityServings;
                VariableServiceFee = 0;
                
                if (QuantityServings >= MaxFreeServiceForServings)
                {
                    VariableServiceFee = 0;
                }
                else
                {
                    for(int iCounter = 0; iCounter < ServingsRangeValues.Length; iCounter++)
                    {
                        if (QuantityServings <= ServingsRangeValues[iCounter])
                        {
                            VariableServiceFee = InitialCost * ServiceFees[iCounter];
                        }                              
                    }
                }
                //Variable to calculate the Adjusted Final Cost for the form to display.
                double AdjustedCostFinal = InitialCost + VariableServiceFee;
                //Variable to calculate the Shipment Final Cost for the form to disaplay.
                double ShipmentCostFinal = AdjustedCostFinal * ShipmentFee[cbxCity.SelectedIndex];
                //Variable to calculate the Final Total Cost for the form to display.
                double FinalTotalCost = AdjustedCostFinal + ShipmentCostFinal;

                //Displays all of the data in the Labels on the form for all of the calculations above.
                lblInitialCost.Text = $"{InitialCost:C}";
                lblAdjustedCost.Text = $"{AdjustedCostFinal:C}";
                lblShipmentCost.Text = $"{ShipmentCostFinal:C}";
                lblTotalPrice.Text = $"{FinalTotalCost:C}";
            }
            

        }
    }
}
