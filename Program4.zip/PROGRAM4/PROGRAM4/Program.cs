﻿//Grading ID: S5008
//Lab Number: Program 04
//Due Date: December 04, 6:00 P.M.
//Course Section: CIS 199-50-4218
//Program Description: Program that displays the title, author, publisher, year of publication, ISBN, and checkout status of a library book.
using System;

namespace PROGRAM4
{
    public class LibraryBook
    {
        public String _bookTitle; //Created String Variable for the Title of the book.
        public String _bookAuthor; //Created String variable for the Author of the book.
        public String _bookPublisher; //Created String variable for the Publisher of the book.
        public int _yearofPublication; //Created Int variable for the Publication Year of the book.
        public String _ISBN; //Created String variable for the ISBN of the book for lookup.
        public bool _bookCheckoutStatus; //Created a Bool variable for use in the checked out status.

        public LibraryBook(String bookTitle1, String bookAuthor1, String bookPublisher1, int yearofPublication1, String ISBN1)
        {
            BookTitle = bookTitle1;
            BookAuthor = bookAuthor1;
            BookPublisher = bookPublisher1;
            YearofPublication = yearofPublication1;
            Main_ISBN = ISBN1;
            _bookCheckoutStatus = false;
        }

        public String BookTitle //Created String with get/set to return a value.
        {
            get
            {
                return _bookTitle;
            }
            set
            {
                _bookTitle = value;
            }
        }

        public String BookAuthor //Created String with get/set to return value.
        {
            get
            {
                return _bookAuthor;
            }
            set
            {
                _bookAuthor = value;
            }
        }
        public String BookPublisher //Created String with get/set to return value.
        {
            get
            {
                return _bookPublisher;
            }
            set
            {
                _bookPublisher = value;
            }
        }
        public int YearofPublication //Created Int with get/set to return value.
        {
            get
            {
                return _yearofPublication;
            }
            set
            {
                _yearofPublication = value;
            }
        }
        public String Main_ISBN //Created String with get/set to return value.
        {
            get
            {
                return _ISBN;
            }
            set
            {
                _ISBN = value;
            }
        }

        public void Checkout() //Created method from the directions to change the book being checked out.
        {
            _bookCheckoutStatus = !_bookCheckoutStatus;
        }

        public void ReturnToShelf() //Created a method from the directions to change the book being checked back in.
        {
            _bookCheckoutStatus = !_bookCheckoutStatus;
        }
        public bool IsCheckedOut() //Created a boolean method to show whether or not the book is on the shelf or not via the above two methods (IsCheckedOut and ReturnToShelf).
        {
            return _bookCheckoutStatus;
        }
        public override String ToString() //Created a method to show the the book status with all of the other information.
        {
            String DisplayData = "";
            DisplayData = "Title of the Book" + _bookTitle + "Author of the Book" + _bookAuthor + "Publisher of the Book" + _bookPublisher + "Year of Publication" + _yearofPublication + "ISBN of the Book" + _ISBN + "Is Book Checked Out" + _bookCheckoutStatus;
            return DisplayData;
        }
    }
        
    
}


