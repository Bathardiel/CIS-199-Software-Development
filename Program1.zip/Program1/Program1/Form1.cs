﻿//Grading ID: S5008
//Lab Number: Program 1
//Due Date: Septemeber 30, 11:59 P.M.
//Course Section: CIS 199-50-4218
//Program Description: Program that asks the user for inputs of size of a pool along with price for accurate Material, Labor, Excavation, and Total Costs.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            //NAMED CONSTANTS
            const double LaborCharge = 3.25;                                        //This is the labor charge to multiply with Cubic Yards for the Labor Price.
            const double CubicDivision = 27;                                        //This is the number to divide by to convert cubic feet to cubic yards.
            const double DivingBoardCost = 50;                                      //This is the extra charge for the Diving board.
            const double MaterialWastePercentage = 0.10;                            //This is the 10% extra charge for materials.
            const double ExcavationPrice = 15;                                      //This is the $15 per cubic yard for Excavation price.
            
            //VARIABLES FOR CALCs
            double MaxWidthOfPool;                                                  //Creates a variable for use in calculations from the Text entered in the associated text box.
                MaxWidthOfPool = double.Parse(TxtMaxWidthOfPool.Text);              //Converts The contents of the text box to numerical values for use in calculations.
            double MaxLengthOfPool;                                                 //Creates a variable for use in calculations from the Text entered in the associated text box.
                MaxLengthOfPool = double.Parse(TxtMaxLengthOfPool.Text);            //Converts The contents of the text box to numerical values for use in calculations.
            double MaxDepthOfPool;                                                  //Creates a variable for use in calculations from the Text entered in the associated text box.
                MaxDepthOfPool = double.Parse(TxtMaxDepthOfPool.Text);              //Converts The contents of the text box to numerical values for use in calculations.
            double MaterialsPrice;                                                  //Creates a variable for use in calculations from the Text entered in the associated text box.
                MaterialsPrice = double.Parse(TxtMaterialsPrice.Text);              //Converts The contents of the text box to numerical values for use in calculations.
            int ExcavationNeeded;                                                   //Creates a variable for use in calculations from the Text entered in the associated text box.
                ExcavationNeeded = int.Parse(TxtExcavationNeeded.Text);             //Converts The contents of the text box to numerical values for use in calculations.
            int DivingBoardNeeded;                                                  //Creates a variable for use in calculations from the Text entered in the associated text box.
                DivingBoardNeeded = int.Parse(TxtDivingBoard.Text);                 //Converts The contents of the text box to numerical values for use in calculations.
            double CubicFeetTotal;                                                  //Creates the Variable for Cubic Feet Total that is defined on the next line.
                CubicFeetTotal = MaxWidthOfPool * MaxLengthOfPool * MaxDepthOfPool; //Multiplies above variable to get the Cubic Feet Total.
            double CubicYardsTotal;                                                 //Creates the variable for the conversion of Cubic Feet to Cubic Yards that is defined on the next line.
                CubicYardsTotal = CubicFeetTotal / CubicDivision;                   //Divided Cubic Feet by 27 as defined with the named constant of 27.
            
            //MATERIALS
            double MaterialsCost;                                                   //Creates the variable for the Materials Cost as defined on hte next line.
                MaterialsCost = MaterialsPrice * CubicYardsTotal;                   //Multiplies the Materials Price by the Cubic Yard to get the Materials cost WITHOUT the 10% extra.
            double MaterialWaste;                                                   //Creates the variable for the Materials Waste as defined below.
                MaterialWaste = MaterialWastePercentage * MaterialsCost;            //Uses the named constant for the 10% extra for the wast to help with calculating the final cost of Materials.
            double MaterialsCostFinal;                                              //Creates the variable for the Final Materials cost with the 10% waste fee added in, defined on the next line.
                MaterialsCostFinal = MaterialWaste + MaterialsCost;                 //Uses the 10% waste fee and adds it to the Materials cost for the Fianl cost to the customer.
            
            //EXCAVATION
            double ExcavationCost;                                                  //Creates the variable for Excavation Cost as defined on the next line.
                ExcavationCost = ExcavationPrice * CubicYardsTotal;                 //Uses the named constant for $15 per cubic yard Excavation Price to calculate Excavation Costs.
            int ExcavationValue;                                                    //Creates the variable for the excavation value to be 1 or 0 in the text box.
                ExcavationValue = int.Parse(TxtExcavationNeeded.Text);              //Defines the value as a numeral to use in the calculations.
            double ExcavationFinal;                                                 //Creates the variable for the final excavation value, defined on next line.
                ExcavationFinal = ExcavationValue * ExcavationCost;                 //Multiplies the ExcavationValue by the cost to either get the amount or show as 0.

            //LABOR
            double LaborCost;                                                       //Creates a variable for Labor cost as defined on the next line.
                LaborCost = CubicYardsTotal * LaborCharge;                          //Creates Labor Cost by muliplying Cubic Yards by the Labor charge constant defined above.
            double LaborCostWithDivingBoard;                                        //Creates a variable for the diving board cost added to the original Labor cost defined on the next line.
                LaborCostWithDivingBoard = LaborCost + DivingBoardCost;             //Adds the named constant for the Diving board cost with the original Labor cost.                                      
            int DivingBoardValue;                                                   //Creates the Variable to represent YES or NO for including the diving board in the calculations.    
                DivingBoardValue = int.Parse(TxtDivingBoard.Text);                  //Converts the contents of the Diving Board Text box to numerical value to be used in calculations.
            double LaborCostFinal;                                                  //Creates the variabgle to represent the final cost with the installation of the Diving Board, multiply by whatever the value is in the Text box.
                LaborCostFinal = DivingBoardCost * DivingBoardValue + LaborCost;    //Adds all the Labor costs together to define the variable.

            //TOTAL
            double TotalCost;                                                       //Creates the varibale for the Total Cost of all the different consts, defined on next line.
                TotalCost = MaterialsCostFinal + ExcavationFinal + LaborCostFinal;  //Adds all the final costs of labor, excavation if needed, diving board, and labor.
            
            //DISPLAYS
            LblCubicYards.Text = $"{CubicYardsTotal:F1}";
            LblMaterialCost.Text = $"{MaterialsCostFinal:C}";
            LblExcavationCost.Text = $"{ExcavationFinal:C}";
            LblLaborCost.Text = $"{LaborCostFinal:C}";
            LblTotalCost.Text = $"{TotalCost:C}";
            
        }
    }
}
