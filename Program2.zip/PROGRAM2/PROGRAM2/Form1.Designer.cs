﻿
namespace PROGRAM2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CboxCarType = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LblLowestCost = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LblCompanyACost = new System.Windows.Forms.Label();
            this.LblCompanyBCost = new System.Windows.Forms.Label();
            this.LblCompanyCCost = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.TxtPassengers = new System.Windows.Forms.TextBox();
            this.TxtDistance = new System.Windows.Forms.TextBox();
            this.BtnCalculate = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CboxCarType
            // 
            this.CboxCarType.FormattingEnabled = true;
            this.CboxCarType.Items.AddRange(new object[] {
            "Limo",
            "Luxury",
            "Mid-Tier",
            "Green",
            "Economy"});
            this.CboxCarType.Location = new System.Drawing.Point(112, 110);
            this.CboxCarType.Name = "CboxCarType";
            this.CboxCarType.Size = new System.Drawing.Size(121, 21);
            this.CboxCarType.TabIndex = 0;
            
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.LblCompanyCCost);
            this.groupBox1.Controls.Add(this.LblCompanyBCost);
            this.groupBox1.Controls.Add(this.LblCompanyACost);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.LblLowestCost);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(252, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(216, 175);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Results";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Company A Cost";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Company B Cost";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(6, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Company C Cost";
            
            // 
            // LblLowestCost
            // 
            this.LblLowestCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblLowestCost.Location = new System.Drawing.Point(20, 141);
            this.LblLowestCost.Name = "LblLowestCost";
            this.LblLowestCost.Size = new System.Drawing.Size(183, 19);
            this.LblLowestCost.TabIndex = 3;
            this.LblLowestCost.Text = "The lowest cost company is: ";
            this.LblLowestCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(100, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 4;
            // 
            // LblCompanyACost
            // 
            this.LblCompanyACost.BackColor = System.Drawing.Color.White;
            this.LblCompanyACost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblCompanyACost.Location = new System.Drawing.Point(103, 26);
            this.LblCompanyACost.Name = "LblCompanyACost";
            this.LblCompanyACost.Size = new System.Drawing.Size(100, 20);
            this.LblCompanyACost.TabIndex = 5;
            // 
            // LblCompanyBCost
            // 
            this.LblCompanyBCost.BackColor = System.Drawing.Color.White;
            this.LblCompanyBCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblCompanyBCost.Location = new System.Drawing.Point(103, 63);
            this.LblCompanyBCost.Name = "LblCompanyBCost";
            this.LblCompanyBCost.Size = new System.Drawing.Size(100, 20);
            this.LblCompanyBCost.TabIndex = 6;
            // 
            // LblCompanyCCost
            // 
            this.LblCompanyCCost.BackColor = System.Drawing.Color.White;
            this.LblCompanyCCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblCompanyCCost.Location = new System.Drawing.Point(103, 100);
            this.LblCompanyCCost.Name = "LblCompanyCCost";
            this.LblCompanyCCost.Size = new System.Drawing.Size(100, 20);
            this.LblCompanyCCost.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(9, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "Passengers (1-12)";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(9, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 16);
            this.label10.TabIndex = 3;
            this.label10.Text = "Distance (Miles)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(9, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 16);
            this.label11.TabIndex = 4;
            this.label11.Text = "Car Type";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TxtPassengers
            // 
            this.TxtPassengers.Location = new System.Drawing.Point(112, 22);
            this.TxtPassengers.Name = "TxtPassengers";
            this.TxtPassengers.Size = new System.Drawing.Size(121, 20);
            this.TxtPassengers.TabIndex = 5;
            // 
            // TxtDistance
            // 
            this.TxtDistance.Location = new System.Drawing.Point(112, 66);
            this.TxtDistance.Name = "TxtDistance";
            this.TxtDistance.Size = new System.Drawing.Size(121, 20);
            this.TxtDistance.TabIndex = 6;
            // 
            // BtnCalculate
            // 
            this.BtnCalculate.Location = new System.Drawing.Point(112, 153);
            this.BtnCalculate.Name = "BtnCalculate";
            this.BtnCalculate.Size = new System.Drawing.Size(114, 23);
            this.BtnCalculate.TabIndex = 7;
            this.BtnCalculate.Text = "Calculate Cost";
            this.BtnCalculate.UseVisualStyleBackColor = true;
            this.BtnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(486, 198);
            this.Controls.Add(this.BtnCalculate);
            this.Controls.Add(this.TxtDistance);
            this.Controls.Add(this.TxtPassengers);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CboxCarType);
            this.Name = "Form1";
            this.Text = "IRYdeShare Cost Calculation";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CboxCarType;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LblCompanyACost;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LblLowestCost;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblCompanyCCost;
        private System.Windows.Forms.Label LblCompanyBCost;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TxtPassengers;
        private System.Windows.Forms.TextBox TxtDistance;
        private System.Windows.Forms.Button BtnCalculate;
    }
}

