﻿//Grading ID: S5008
//Lab Number: Program 02
//Due Date: October 21, 11:59 P.M.
//Course Section: CIS 199-50-4218
//Program Description: Program to compare three different companies to each othre for price and number of passengers.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROGRAM2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            double TotalA;                      //Variable for the sum total of Company A calculations.
            double TotalB;                      //Variable for the sum total of Company B calculations.
            double TotalC;                      //Variable for the sum total of Company C calculations.
        private void BtnCalculate_Click(object sender, EventArgs e) //EVENT HANDLER FOR MAKING THE CALCULATIONS.
        {
            //NAMED CONSTANTS COMPANY "A"
            const int aPassengerFee = 2;        //Constant for the Company A passenger fee.
            const double aPerMileFee = 0.02;    //Constant for the Distance per mile fee.
            const int aLimoFee = 50;            //Constant for the Company A Limo fee.
            const int aLuxuryFee = 40;          //Constant for the Company A Luxury Fee.
            const int aMidTierFee = 25;         //Constant for the Company A Mid-Tier fee.
            const int aGreenFee = 15;           //Constant for the Company A Green fee.
            const int aEconomyFee = 7;          //Constant for the Company A Economy fee.

            //NAMED CONSTANTS COMPANY "B"
            const int bPassengerFee20 = 20;     //Constant for the Company B higher passenger rate fee.
            const int bPassengerFee15 = 15;     //Constant for the Company B mid-level passenger rate fee.
            const int bPassengerFee5 = 5;       //Constant for the Company B lower rate passenger rate fee.
            const double bPerMileFee = 0.10;    //Constant for the Company B Distance per mile fee.
            const int bLimoAndLuxuryFee = 40;   //COnstant for the Company B Limo and Luxury fee.
            const int bMidTierFee = 25;         //Constant for the Company B mid-tier fee.
            const int bGreenAndEconomyFee = 15; //Constnat for the Company Green and Economy fee.

            //NAMED CONSTANTS COMPANY "C"
            const double cPassengerFee = 0.25;  //Constant for the Company C passenger fee.
            const int cPerMileFee40 = 40;       //Constant for the Company C highest Distance per mile fee.
            const int cPerMileFee35 = 35;       //Constant for the Company C higher Distance per mile fee.
            const int cPerMileFee25 = 25;       //Constant for the Company C middle Distance per mile fee.
            const int cPerMileFee15 = 15;       //Constant for the Company C lower Distance per mile fee.
            const int CPerMileFee5 = 5;         //Constant for the Company C lowest Distance per mile fee.
            const int cAllCarTypeFee = 20;      //Constant for the Company C car type fees.

            //OVERALL LOCAL VARIABLES
            int NumPassengers;                 //Variable for the input of number of passnegers.
            int NumDistance;                   //Variable for the input of distance in miles.
                       
            //CUSTOMER INPUTS FOR LOCAL VARIABLES
            int.TryParse(TxtPassengers.Text, out NumPassengers);
            int.TryParse(TxtDistance.Text, out NumDistance);
                          
            //COMPANY "A" CALCULATIONS
                if (CboxCarType.Text == "Limo")
                {
                    TotalA = (aPassengerFee * NumPassengers) + (aPerMileFee * NumDistance) + aLimoFee;
                    LblCompanyACost.Text = $"{TotalA:C}";
                }
                else if (CboxCarType.Text == "Luxury")
                {
                    TotalA = (aPassengerFee * NumPassengers) + (aPerMileFee * NumDistance) + aLuxuryFee;
                    LblCompanyACost.Text = $"{TotalA:C}";
                }
                else if (CboxCarType.Text == "Mid-Tier")
                {
                    TotalA = (aPassengerFee * NumPassengers) + (aPerMileFee * NumDistance) + aMidTierFee;
                    LblCompanyACost.Text = $"{TotalA:C}";
                }
                else if (CboxCarType.Text == "Green")
                {
                    TotalA = (aPassengerFee * NumPassengers) + (aPerMileFee * NumDistance) + aGreenFee;
                    LblCompanyACost.Text = $"{TotalA:C}";
                }
                else if (CboxCarType.Text == "Economy")
                {
                    TotalA = (aPassengerFee * NumPassengers) + (aPerMileFee * NumDistance) + aEconomyFee;
                    LblCompanyACost.Text = $"{TotalA:C}";
                }
            
                //COMPANY B CALCULATIONS
                    //PASSENGER FEE $5
                if ((CboxCarType.Text == "Limo" || CboxCarType.Text == "Luxury") & (NumPassengers >= 7))
                {
                    TotalB = (bPassengerFee5 * NumPassengers) + (bPerMileFee * NumDistance) + bLimoAndLuxuryFee;
                    LblCompanyBCost.Text = $"{TotalB:C}";
                }
                else if ((CboxCarType.Text == "Limo" || CboxCarType.Text == "Luxury") & (NumPassengers >= 3))
                {
                    TotalB = (bPassengerFee15 * NumPassengers) + (bPerMileFee * NumDistance) + bLimoAndLuxuryFee;
                    LblCompanyBCost.Text = $"{TotalB:C}";
                }
                else if ((CboxCarType.Text == "Limo" || CboxCarType.Text == "Luxury") & (NumPassengers >= 0))
                {
                TotalB = (bPassengerFee20 * NumPassengers) + (bPerMileFee * NumDistance) + bLimoAndLuxuryFee;
                LblCompanyBCost.Text = $"{TotalB:C}";
                }
                else if ((CboxCarType.Text == "Mid-Tier") & (NumPassengers >= 7))
                {
                    TotalB = (bPassengerFee5 * NumPassengers) + (bPerMileFee * NumDistance) + bMidTierFee;
                    LblCompanyBCost.Text = $"{TotalB:C}";
                }
                else if ((CboxCarType.Text == "Mid-Tier") & (NumPassengers >= 3))
                {
                    TotalB = (bPassengerFee15 * NumPassengers) + (bPerMileFee * NumDistance) + bMidTierFee;
                    LblCompanyBCost.Text = $"{TotalB:C}";
                }
                else if ((CboxCarType.Text == "Green" || CboxCarType.Text == "Economy") & (NumPassengers >= 0))
                {
                TotalB = (bPassengerFee20 * NumPassengers) + (bPerMileFee * NumDistance) + bGreenAndEconomyFee;
                LblCompanyBCost.Text = $"{TotalB:C}";
                }                                
                else if ((CboxCarType.Text == "Green" || CboxCarType.Text == "Economy") & (NumPassengers >= 7))
                {
                    TotalB = (bPassengerFee5 * NumPassengers) + (bPerMileFee * NumDistance) + bGreenAndEconomyFee;
                    LblCompanyBCost.Text = $"{TotalB:C}";
                }
                else if ((CboxCarType.Text == "Green" || CboxCarType.Text == "Economy") & (NumPassengers >= 3))
                {
                    TotalB = (bPassengerFee15 * NumPassengers) + (bPerMileFee * NumDistance) + bGreenAndEconomyFee;
                    LblCompanyBCost.Text = $"{TotalB:C}";
                }
                else if ((CboxCarType.Text == "Mid-Tier") & (NumPassengers >= 0))
                {
                TotalB = (bPassengerFee20 * NumPassengers) + (bPerMileFee * NumDistance) + bMidTierFee;
                LblCompanyBCost.Text = $"{TotalB:C}";
                }                                                                                                      
                                                                        
            //COMPANY C CALCULATIONS
                if (NumDistance >= 200)
                {
                    TotalC = (cPassengerFee * NumPassengers) + cPerMileFee40 + cAllCarTypeFee;
                    LblCompanyCCost.Text = $"{TotalC:C}";
                }
                else if (NumDistance >=100)
                {
                    TotalC = (cPassengerFee * NumPassengers) + cPerMileFee35 + cAllCarTypeFee;
                    LblCompanyCCost.Text = $"{TotalC:C}";
                }
                else if (NumDistance >= 50)
                {
                    TotalC = (cPassengerFee * NumPassengers) + cPerMileFee25 + cAllCarTypeFee;
                    LblCompanyCCost.Text = $"{TotalC:C}";
                }
                else if (NumDistance >= 10)
                {
                    TotalC = (cPassengerFee * NumPassengers) + cPerMileFee15 + cAllCarTypeFee;
                    LblCompanyCCost.Text = $"{TotalC:C}";
                }
                else if (NumDistance >= 0)
                {
                    TotalC = (cPassengerFee * NumPassengers) + CPerMileFee5 + cAllCarTypeFee;
                    LblCompanyCCost.Text = $"{TotalC:C}";
                }

            //VERIFY INPUTS ARE CORRECT FROM CUSTOMERS
            if (NumPassengers < 0 || NumPassengers > 12)
                MessageBox.Show("Please Check Passengers.");
            else if (NumDistance < 0)
                MessageBox.Show("Please Check Distance.");
                    
            //LOWEST COST COMPANY LOGIC STATEMENTS
            if (TotalA < TotalB && TotalA < TotalC)
                {
                    LblLowestCost.Text = $"The Lowest Cost Company is: A";
                }
                else if (TotalB < TotalA && TotalB < TotalC)
                {
                    LblLowestCost.Text = $"The Lowest Cost Company is: B";
                }
                else if (TotalC < TotalA && TotalC < TotalB)
                {
                    LblLowestCost.Text = $"The Lowest Cost Company is: C";
                }
                else
                    LblLowestCost.Text = $"The Companies are tied";
        }
    }
}
